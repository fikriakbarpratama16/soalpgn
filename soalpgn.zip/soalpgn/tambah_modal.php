<!-- Tambah Data-->
<div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"style="background-color:#bfbfbf">
            	 <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel"></h4></center>
            </div>
            <div class="modal-body"style="background-color:#bfbfbf">
			<div class="container-fluid">
			<form method="POST" action="tambah.php">
				<div class="row form-group">
            			<label>Nama Guru</label>
            		  <?php 
		              $mysqli = new mysqli ('localhost','root','','guru001');
		              $resultSet = $mysqli->query("SELECT nama FROM guru");
		              ?>
		              <select type ="text" class="form-control" id="nama" name="nama">
		              <option></option>
		              <?php 
		              while ($rows = $resultSet->fetch_assoc())
		              {
		              $nama = $rows ['nama'];
		              echo "<option>$nama</option>";
		              }
		              ?>
              </select>
            	</div>
				<div class="row form-group">
            			<label>NIP</label>
            			<?php 
		              $mysqli = new mysqli ('localhost','root','','guru001');
		              $resultSet = $mysqli->query("SELECT nip FROM nip");
		              ?>
		              <select type ="text" class="form-control" id="nip" name="nip">
		              <option></option>
		              <?php 
		              while ($rows = $resultSet->fetch_assoc())
		              {
		              $nip = $rows ['nip'];
		              echo "<option>$nip</option>";
		              }
		              ?>
              </select>
            	</div>				
				<div class="row form-group">
						<label>Pangkat/Golongan</label>
					<?php 
		              $mysqli = new mysqli ('localhost','root','','guru001');
		              $resultSet = $mysqli->query("SELECT pangkat FROM pangkat");
		              ?>
		              <select type ="text" class="form-control" id="pangkat" name="pangkat">
		              <option></option>
		              <?php 
		              while ($rows = $resultSet->fetch_assoc())
		              {
		              $pangkat = $rows ['pangkat'];
		              echo "<option>$pangkat</option>";
		              }
		              ?>
              </select>
				</div>
				<div class="row form-group">
						<label>TMT Awal</label>
						<input type="date" id="tmt" class="form-control" name="tmt">
				</div>
				<div class="row form-group">
            			<label>Jabatan</label>
            			<input type="text" id="jabatan" class="form-control" name="jabatan">
            	</div>
				<div class="row form-group">
						<label>Mata Pelajaran</label>
						<input type="text" id="mapel" class="form-control" name="mapel">
				</div>
				<div class="row form-group">
						<label>Jumlah Jam Mengajar (JJM)</label>
						<input type="text" id="jjm" class="form-control" name="jjm">
				</div>
				<div class="row form-group">
						<label>Alamat</label>
						<textarea type="text" rows="3" id="alamat" class="form-control" name="alamat"></textarea>
				</div>
				<div class="row form-group">
						<label>Email</label>
						<input type="email" id="email" class="form-control" name="email">
				</div>
				<div class="row form-group">
						<label>No.Telepon</label>
						<input type="number" id="kontak" class="form-control" name="kontak">
				</div>
            </div> 
			</div>
            <div class="modal-footer"style="background-color:#bfbfbf">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Batal</button>
                <button type="submit" name="tambah" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Simpan</a>
			</form>
            </div>

        </div>
    </div>
</div>