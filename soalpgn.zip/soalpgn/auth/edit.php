<?php
	session_start();
	include_once('koneksi.php');
	if(isset($_POST['edit'])){
		$id = $_POST['id']; 
		$nama = $_POST['nama'];
		$nip = $_POST['nip'];
		$pangkat = $_POST['pangkat'];
		$tmt = $_POST['tmt'];
		$jabatan = $_POST['jabatan'];
		$mapel = $_POST['mapel'];
		$jjm = $_POST['jjm'];
		$alamat = $_POST['alamat'];
		$email = $_POST['email'];
		$kontak = $_POST['kontak'];
		$sql = "UPDATE data SET nama = '$nama', nip = '$nip', pangkat = '$pangkat', tmt = '$tmt', jabatan = '$jabatan' , mapel = '$mapel', jjm = '$jjm', alamat = '$alamat', email = '$email', kontak = '$kontak' WHERE id = '$id'";

		if($conn->query($sql)){
			$_SESSION['success'] = 'Data berhasil diperbarui!';
		}
		
		else{
			$_SESSION['error'] = 'Gagal perbarui data!';
		}
	}
	else{
		$_SESSION['error'] = 'Pilih data yang ingin diperbarui!';
	}

	header('location: index.php');

?> 