<?php include('koneksi.php'); ?>
<?php
    header("Content-type:application/vnd-ms-excel");
    header("Content-Disposition: attachment; filename=Data Pegawai 001.xls");
?>
    
    <table id="example" class="table table-striped table-bordered dt-responsive table-hover" style="width:100%">
      <h2 class="text-center">INFORMASI DATA PEGAWAI</h2>
              <thead>
                <th>ID</th>
                <th>Nama_Guru</th>
                <th>Nama Department</th>
               
                <th>Tanggal Penyimpanan</th>
                
                <th>Simpanan</th>
                
              </thead>
    <tbody>
    <?php
     $conn = mysqli_connect("localhost", "root", "", "guru001");
     $data = mysqli_query($conn, "SELECT * FROM data");
     while($row = mysqli_fetch_array($data)){
    ?>
    <tr>
        <td><?php echo $row['id'] ?></td>
        <td><?php echo $row['nama'] ?></td>
        <td><?php echo $row['nip'] ?></td>
        
        <td><?php echo $row['tmt'] ?></td>
        
        <td><?php echo $row['jjm'] ?></td>
        
    </tr>
    <?php } ?>
    </tbody>
    </table>

</body>
</html>