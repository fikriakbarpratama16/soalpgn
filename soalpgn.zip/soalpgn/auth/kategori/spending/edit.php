<?php
	session_start();
	include_once('koneksi.php');
	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$pangkat = $_POST['pangkat'];
		$sql = "UPDATE pangkat SET pangkat = '$pangkat' WHERE id = '$id'";

		if($conn->query($sql)){
			$_SESSION['success'] = 'Pangkat/Gol berhasil diperbarui!';
		}
		
		else{
			$_SESSION['error'] = 'Gagal perbarui data!';
		}
	}
	else{
		$_SESSION['error'] = 'Pilih data yang ingin diperbarui!';
	}

	header('location: index.php');

?> 