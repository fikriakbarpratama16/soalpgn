<!-- Edit -->
<div class="modal fade" id="edit_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"style="background-color:#bfbfbf">
            	 <h5 class="modal-title" id="exampleModalLabel">Update Pangkat/Gol</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel"></h4></center>
            </div>
            <div class="modal-body"style="background-color:#bfbfbf">
			<div class="container-fluid">
			<form method="POST" action="edit.php">
				<input type="hidden" class="form-control" name="id" value="<?php echo $row['id']; ?>">
				<div class="row form-group">
						<label class="control-label modal-label">Pangkat/Golongan</label>
						<input type="text" class="form-control" name="pangkat" value="<?php echo $row['pangkat']; ?>">
				</div>
            </div> 
			</div>
            <div class="modal-footer"style="background-color:#bfbfbf">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Batal</button>
                <button type="submit" name="edit" class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Update</a>
			</form>
            </div>

        </div>
    </div>
</div>

<!-- Hapus-->
<div class="modal fade" id="hapus_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"style="background-color:#bfbfbf">
            	 <h5 class="modal-title" id="exampleModalLabel">Hapus Pangkat/Golongan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel"></h4></center>
            </div>
            <div class="modal-body"style="background-color:#bfbfbf">	
            	<p class="text-center">Yakin ingin menghapus pangkat/Golongan?</p>
				<h2 class="text-center" style="font-size: 15px;font-weight: bold;"><?php echo $row['pangkat']; ?></h2>
			</div>
            <div class="modal-footer"style="background-color:#bfbfbf">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Batal</button>
                <a href="hapus.php?id=<?php echo $row['id']; ?>" class="btn btn-primary"><span class="glyphicon glyphicon-trash"></span> Hapus</a>
            </div>

        </div>
    </div>
</div>