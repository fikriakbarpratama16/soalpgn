<?php
	session_start();
	include_once('koneksi.php');

	if(isset($_POST['tambah'])){
		$pangkat = $_POST['pangkat'];
		$sql = "INSERT INTO pangkat (pangkat) VALUES ('$pangkat')";
 
		if($conn->query($sql)){
			$_SESSION['success'] = 'Pangkat/Gol berhasil disimpan!';
		}
		
		else{
			$_SESSION['error'] = 'Terjadi kesalahan!';
		}
	}
	else{
		$_SESSION['error'] = 'Lengkapi semua data!';
	}

	header('location: index.php');
?>