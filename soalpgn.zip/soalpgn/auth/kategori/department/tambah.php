<?php
	session_start();
	include_once('koneksi.php');

	if(isset($_POST['tambah'])){
		$nip = $_POST['nip'];
		$sql = "INSERT INTO nip (nip) VALUES ('$nip')";
 
		if($conn->query($sql)){
			$_SESSION['success'] = 'Department berhasil disimpan!';
		}
		
		else{
			$_SESSION['error'] = 'Terjadi kesalahan!';
		}
	}
	else{
		$_SESSION['error'] = 'Lengkapi semua data!';
	}

	header('location: index.php');
?>