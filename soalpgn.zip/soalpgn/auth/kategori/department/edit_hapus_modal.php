<!-- Edit -->
<div class="modal fade" id="edit_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"style="background-color:#bfbfbf">
                 <h5 class="modal-title" id="exampleModalLabel">Update Department</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel"></h4></center>
            </div>
            <div class="modal-body"style="background-color:#bfbfbf">
            <div class="container-fluid">
            <form method="POST" action="edit.php">
                <input type="hidden" class="form-control" name="id" value="<?php echo $row['id']; ?>">
                <div class="row form-group">
                        <label class="control-label modal-label">Department</label>
                        <input type="text" class="form-control" name="nip" value="<?php echo $row['nip']; ?>">
                </div>
            </div> 
            </div>
            <div class="modal-footer"style="background-color:#bfbfbf">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Batal</button>
                <button type="submit" name="edit" class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Update</a>
            </form>
            </div>

        </div>
    </div>
</div>

<!-- Hapus-->
<div class="modal fade" id="hapus_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"style="background-color:#bfbfbf">
                 <h5 class="modal-title" id="exampleModalLabel">Hapus Department</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel"></h4></center>
            </div>
            <div class="modal-body"style="background-color:#bfbfbf">    
                <p class="text-center">Yakin ingin menghapus NIP?</p>
                <h2 class="text-center" style="font-size: 15px;font-weight: bold;"><?php echo $row['nip']; ?></h2>
            </div>
            <div class="modal-footer"style="background-color:#bfbfbf">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Batal</button>
                <a href="hapus.php?id=<?php echo $row['id']; ?>" class="btn btn-primary"><span class="glyphicon glyphicon-trash"></span> Hapus</a>
            </div>

        </div>
    </div>
</div>