<!-- Tambah Data-->
<div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"style="background-color:#bfbfbf">
            	 <h5 class="modal-title" id="exampleModalLabel">Tambah Department</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel"></h4></center>
            </div>
            <div class="modal-body"style="background-color:#bfbfbf">
			<div class="container-fluid">
			<form method="POST" action="tambah.php">
				<div class="row form-group">
            			<label>Daftar Department</label>
            			<input type="text" id="nip" class="form-control" name="nip">
            	</div>
            </div> 
			</div>
            <div class="modal-footer"style="background-color:#bfbfbf">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span>Batal</button>
                <button type="submit" name="tambah" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Simpan</a>
			</form>
            </div>

        </div>
    </div>
</div>