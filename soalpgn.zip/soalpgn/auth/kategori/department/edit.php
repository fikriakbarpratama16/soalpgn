<?php
	session_start();
	include_once('koneksi.php');
	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$nip = $_POST['nip'];
		$sql = "UPDATE nip SET nip = '$nip' WHERE id = '$id'";

		if($conn->query($sql)){
			$_SESSION['success'] = 'Department berhasil diperbarui!';
		}
		
		else{
			$_SESSION['error'] = 'Gagal perbarui data!';
		}
	}
	else{
		$_SESSION['error'] = 'Pilih data yang ingin diperbarui!';
	}

	header('location: index.php');

?> 