<?php
	session_start();
	include_once('koneksi.php');
	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$nama = $_POST['nama'];
		$sql = "UPDATE guru SET nama = '$nama' WHERE id = '$id'";

		if($conn->query($sql)){
			$_SESSION['success'] = 'Nama guru berhasil diperbarui!';
		}
		
		else{
			$_SESSION['error'] = 'Gagal perbarui data!';
		}
	}
	else{
		$_SESSION['error'] = 'Pilih data yang ingin diperbarui!';
	}

	header('location: index.php');

?> 