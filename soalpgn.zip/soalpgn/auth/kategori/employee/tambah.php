<?php
	session_start();
	include_once('koneksi.php');

	if(isset($_POST['tambah'])){
		$nama = $_POST['nama'];
		$sql = "INSERT INTO guru (nama) VALUES ('$nama')";
 
		if($conn->query($sql)){
			$_SESSION['success'] = 'Data berhasil disimpan!';
		}
		
		else{
			$_SESSION['error'] = 'Terjadi kesalahan!';
		}
	}
	else{
		$_SESSION['error'] = 'Lengkapi semua data!';
	}

	header('location: index.php');
?>