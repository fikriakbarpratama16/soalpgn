<?php include('koneksi.php'); 
session_start();
if(!isset($_SESSION['session_username'])){
    header("location:login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/datatables-1.10.25.min.css" />
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/select/1.3.1/css/select.bootstrap.min.css" />
  <link href=" https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.bootstrap5.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" rel="stylesheet" />
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <title>Data Pegawai</title>
</head>
<body>
	<header class="header">
    <div class="logo">PGN Perkasa</div>

    <input type="checkbox" id="toggle">
    <label for="toggle"><img src="img/menu.png" alt=" menu"></label>

    <nav class="navigation">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="#">Kategori</a>
          <ul>
            <li><a href="kategori/employee/index.php">Nama Pegawai <span><i class="fa fa-user-tie"></i></span></a></li>
            <li><a href="kategori/department/index.php">Nama Department<span><i class="fa fa-id-card"></i></span></a></li>
          </li>
          </ul>
        </li>
        <li><a href="../index.php">User Page</a></li>
        <li><a href="../logout.php">Logout</a></li>
      </ul>
    </nav>
  </header>

<div class="container-fluid">
	<h4 class="text-center mt-2">PGN Perkasa</h4><br>
   <p style="font-weight: bold;" class="datatable design text-center">INFORMASI DATA KEPEGAWAIAN</p>
	<div class="row">
		<div class="col-sm-12">
			<div class="row">
			<div class="button" style="text-align: center;">
			<a href="#tambah" data-toggle="modal" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Tambah Data</a>
			 <a href="export.php" class="btn btn-success btn-sm"><i class="fa fa-file-export"> Report</a></i>
		  </div>
			<div class="col-sm-12"style="margin-top: 8px;">
				<table id="myTable" class="table table-bordered dt-responsive table-hover" style="width: 100%;font-family:serif ;background-color:#9e9e9e;color: #000;">
					<thead>
						<th><i class='fa fa-edit'></i></th>
						<th><i class='fa fa-eye'></i></th>
						<th><i class='fa fa-trash'></i></th>
						<th>ID</th>
						<th>Nama_Guru</th>
						<th>Nama Department</th>
						
						<th>Tanggal Penyimpanan</th>
						
						<th>Simpanan</th>
						
					</thead>
					<tbody>
						<?php
							include_once('koneksi.php');
							$sql = "SELECT * FROM data";
							$query = $conn->query($sql);
							while($row = $query->fetch_assoc()){
								echo 
								"<tr>
								<td>
										<a href='#edit_".$row['id']."' class='btn btn-info btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-edit'></span><i class='fa fa-edit'></i></a></td>
								<td>
										<a href='#lihat_".$row['id']."' class='btn btn-warning btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-eye'></span><i class='fa fa-eye'></i></a></td>
								<td>
										<a href='#hapus_".$row['id']."' class='btn btn-danger btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span><i class='fa fa-trash'></i></a></td>
									</td>
									<td>".$row['id']."</td>
									<td>".$row['nama']."</td>
									<td>".$row['nip']."</td>
									
									<td>".$row['tmt']."</td>
									
									<td>".$row['jjm']."</td>
									
								</tr>";
								include('lihat_data.php');
								include('edit_hapus_modal.php');
							}

						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<?php include('tambah_modal.php') ?>
 <script src="js/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/dt-1.10.25datatables.min.js"></script>
<!-- generate datatable on our table -->
<script>
 $(document).ready(function() {
      $('#myTable').DataTable({
        'paging': 'true',
        'order': [],
        'lengthMenu': [[5, 10, 20, 30, 40, 50, 100, -1], [5, 10, 20, 30, 40, 50, 100, "All"]],
      });
    });
    //hide alert
    $(document).on('click', '.close', function(){
    	$('.alert').hide();
    })
</script>
</body>
<footer><div class="ft"><p>&copy; 2023 <a href="#" style="color:#2929ff">Fikri Akbar Pratama.</a><span style="color:#000"> All rights reserved</span></p></div></footer>
<style>
.ft{
	text-align: center;
}
a{
	color:navy;
}
</style>
</html>
