<?php
	session_start();
	include_once('koneksi.php');

	if(isset($_GET['id'])){
		$sql = "DELETE FROM data WHERE id = '".$_GET['id']."'";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Data berhasil dihapus!';
		}
	
		else{
			$_SESSION['error'] = 'Terjadi kesalahan!';
		}
	}
	else{
		$_SESSION['error'] = 'Pilih data yang ingin dihapus!';
	}

	header('location: index.php');
?>