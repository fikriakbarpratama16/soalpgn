<?php
	session_start();
	include_once('koneksi.php');
	if(isset($_POST['tambah'])){
		$nama = $_POST['nama'];
		$nip = $_POST['nip'];
		$pangkat = $_POST['pangkat'];
		$tmt = $_POST['tmt'];
		$jabatan = $_POST['jabatan'];
		$mapel = $_POST['mapel'];
		$jjm = $_POST['jjm'];
		$alamat = $_POST['alamat'];
		$email = $_POST['email'];
		$kontak = $_POST['kontak'];
		$sql = "INSERT INTO data (nama,nip,pangkat,tmt,jabatan,mapel,jjm,alamat,email,kontak) VALUES ('$nama', '$nip', '$pangkat', '$tmt', '$jabatan', '$mapel', '$jjm', '$alamat', '$email', '$kontak')";
 
		if($conn->query($sql)){
			$_SESSION['success'] = 'Data berhasil disimpan!';
		}
		
		else{
			$_SESSION['error'] = 'Terjadi kesalahan!';
		}
	}
	else{
		$_SESSION['error'] = 'Lengkapi semua data!';
	}

	header('location: index.php');
?>