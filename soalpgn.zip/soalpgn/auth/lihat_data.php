<div class="modal fade" id="lihat_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content"style="text-align: center;background-color: #b8b8b8;color: #000;">
            <div class="modal-body">
			<div class="container-fluid">
				<img align-center src="img/user.jpg" style="height:18%;text-align: center;"><br>INFORMASI DATA PEGAWAI<hr>
			<form method="POST" action="lihat.php">
				<input type="hidden" class="form-control" name="id" value="<?php echo $row['id']; ?>">
				<div class="row form-group">
					<label class="control-label modal-label">Nama Pegawai</label>
					<input style="text-align: center;" type="text" class="form-control" name="nama" value="<?php echo $row['nama']; ?>" readonly>
				</div>
				<div class="row form-group">
						<label class="control-label modal-label">Nama Department</label>
						<input style="text-align: center;" type="text" class="form-control" name="nip" value="<?php echo $row['nip']; ?>" readonly>
				</div>
				
				<div class="row form-group">
						<label class="control-label modal-label">Tanggal Penyimpanan</label>
						<input style="text-align: center;" type="date" class="form-control" name="tmt" value="<?php echo $row['tmt']; ?>"readonly>
				</div>
				
				<div class="row form-group">
						<label class="control-label modal-label">Simpanan</label>
						<input style="text-align: center;" type="text" class="form-control" name="jjm" value="<?php echo $row['jjm']; ?>"readonly>
				</div>
				
				

				 <div class="footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"style="text-align: center;" >Tutup</button>
           		 </div>
			</form>
            </div>
            </div> 
			</div>
			</form>
            </div>
        </div>
    </div>

