<!-- Edit -->
<div class="modal fade" id="edit_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"style="background-color:#bfbfbf">
            	 <h5 class="modal-title" id="exampleModalLabel">Update Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel"></h4></center>
            </div>
            <div class="modal-body"style="background-color:#bfbfbf">
			<div class="container-fluid">
			<form method="POST" action="edit.php">
				<input type="hidden" class="form-control" name="id" value="<?php echo $row['id']; ?>">
				<div class="row form-group">
						<label class="control-label modal-label">Nama Pegawai</label>
						<?php 
		              $mysqli = new mysqli ('localhost','root','','guru001');
		              $resultSet = $mysqli->query("SELECT nama FROM guru");
		              ?>
		              <select type ="text" class="form-control" id="nama" name="nama">
		              <option></option>
		              <?php 
		              while ($rows = $resultSet->fetch_assoc())
		              {
		              $nama = $rows ['nama'];
		              echo "<option selected>$nama</option>";
		              }
		              ?>
		          </select>
				</div>
				<div class="row form-group">
						<label class="control-label modal-label">Nama Department</label>
					  <?php 
		              $mysqli = new mysqli ('localhost','root','','guru001');
		              $resultSet = $mysqli->query("SELECT nip FROM nip");
		              ?>
		              <select type ="text" class="form-control" id="nip" name="nip">
		              <option></option>
		              <?php 
		              while ($rows = $resultSet->fetch_assoc())
		              {
		              $nip = $rows ['nip'];
		              echo "<option>$nip</option>";
		              }
		              ?>
              </select>
				</div>
				<div class="row form-group">
						
				</div>
				<div class="row form-group">
						<label class="control-label modal-label">Tanggal Penyimpanan</label>
						<input type="date" class="form-control" name="tmt" value="<?php echo $row['tmt']; ?>">
				</div>
				
				<div class="row form-group">
						<label class="control-label modal-label">Simpanan</label>
						<input type="text" class="form-control" name="jjm" value="<?php echo $row['jjm']; ?>">
				</div>
				
				
				
            </div> 
			</div>
            <div class="modal-footer"style="background-color:#bfbfbf">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Batal</button>
                <button type="submit" name="edit" class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Update</a>
			</form>
            </div>

        </div>
    </div>
</div>

<!-- Hapus-->
<div class="modal fade" id="hapus_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"style="background-color:#bfbfbf">
            	 <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel"></h4></center>
            </div>
            <div class="modal-body"style="background-color:#bfbfbf">	
            	<p class="text-center">Yakin ingin menghapus data pegawai?</p>
				<h2 class="text-center"style="font-size:15px;font-weight:bold;"><?php echo $row['nama']; ?></h2>
			</div>
            <div class="modal-footer"style="background-color:#bfbfbf">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Batal</button>
                <a href="hapus.php?id=<?php echo $row['id']; ?>" class="btn btn-primary"><span class="glyphicon glyphicon-trash"></span> Hapus</a>
            </div>

        </div>
    </div>
</div>